package com.icehome.up;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/**
 * El icono dibujado en vectores para «Acerca de»: el fondo coral es algo transparente, así que
 * los brillos de color que pasan por detrás lo tiñen (como el de HyperCeiler); la H es blanca y
 * opaca, con el punto del deslizador hueco. Misma geometría que el icono (rejilla de 512).
 */
final class LogoDrawable extends Drawable {

    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG), fg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path squircle = new Path(), glyph = new Path();
    private final RectF r = new RectF();

    LogoDrawable(int color, int alpha) {
        bg.setColor(color);
        bg.setAlpha(alpha);
        fg.setColor(0xFFFFFFFF);
    }

    @Override
    protected void onBoundsChange(Rect b) {
        float s = Math.min(b.width(), b.height()) / 512f;
        float ox = b.left + (b.width() - 512 * s) / 2f, oy = b.top + (b.height() - 512 * s) / 2f;
        squircle.reset();
        r.set(ox, oy, ox + 512 * s, oy + 512 * s);
        squircle.addRoundRect(r, 512 * s * 0.27f, 512 * s * 0.27f, Path.Direction.CW);

        Path p = new Path();
        rr(p, ox, oy, s, 124, 124, 184, 388, 30);
        rr(p, ox, oy, s, 328, 124, 388, 388, 30);
        rr(p, ox, oy, s, 170, 243, 342, 269, 13);
        Path knob = new Path();
        knob.addCircle(ox + 272 * s, oy + 256 * s, 46 * s, Path.Direction.CW);
        p.op(knob, Path.Op.UNION);
        Path hole = new Path();
        hole.addCircle(ox + 272 * s, oy + 256 * s, 17 * s, Path.Direction.CW);
        p.op(hole, Path.Op.DIFFERENCE);
        glyph.set(p);
    }

    private void rr(Path p, float ox, float oy, float s, float l, float t, float rt, float bt, float rad) {
        Path q = new Path();
        r.set(ox + l * s, oy + t * s, ox + rt * s, oy + bt * s);
        q.addRoundRect(r, rad * s, rad * s, Path.Direction.CW);
        p.op(q, Path.Op.UNION);
    }

    @Override
    public void draw(Canvas c) {
        c.drawPath(squircle, bg);
        c.drawPath(glyph, fg);
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
